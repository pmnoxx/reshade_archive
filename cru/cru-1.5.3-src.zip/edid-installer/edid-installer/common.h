#ifndef COMMON_H
#define COMMON_H

/* Includes ***************************************************************/

#define _CRT_SECURE_NO_WARNINGS

#include <windows.h>
#include <stdio.h>
#include <tchar.h>

/* Defines ****************************************************************/

#define TEXTSIZE 256

/**************************************************************************/

#endif
