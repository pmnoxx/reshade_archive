#ifndef RESOURCE_H
#define RESOURCE_H

/* Defines ****************************************************************/

#define TITLE					_T("EDID Installer")
#define INSTALL_TITLE			_T("Install EDID")
#define RESET_TITLE				_T("Reset EDID")

#define IDC_INSTALL				100
#define IDC_RESET				101

/**************************************************************************/

#endif
